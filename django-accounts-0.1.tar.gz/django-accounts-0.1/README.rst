=====
Accounts
=====

Just a simple application for managing user logins and registrations, which provides front-end display and background verification of related pages. it contains serverl urls and view functions, such as `accounts/login/, accounts/register/, accounts/reset_password, accounts/change_password` e.t.c and you can use it easily.

Quick start
-----------

1.Add "accounts" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'accounts',
    ]



2. Include the accounts URLconf in your project urls.py like this::

    path('accounts/', include('accounts.urls')),

3. Run `python manage.py migrate` to create the auth models and more.

4. In order to provide email activation, you must set up a mailbox.If you are not familiar with the mailbox settings, I think you can view https://docs.djangoproject.com/zh-hans/2.2/topics/email/.

5. Start the development server and visit http://127.0.0.1:8000/accounts/register/
   to create a accounts.


