from django.urls import path
from .views import *

# url命名空间
app_name = 'accounts'

urlpatterns = [
    path('', AccountIndex.as_view(), name='profile'),
    path('register/', RegisterView.as_view(), name='register'),
    path('register_send_email/', register_send_email, name='register_send_email'),
    path('login/', LoginView.as_view(), name='login'),
    path('verify_code.png/', verifycode, name='verify_code'),
    path('change_password/', ChangePasswordView.as_view(), name='change_password'),
    path('reset_password/', ResetPasswordView.as_view(), name='reset_password'),
    path('reset_send_email/', reset_send_email, name='reset_send_email'),
    path('protocol_content', protocol_content, name='protocol_content'),
    path('logout/', LogoutView.as_view(), name='logout'),
]