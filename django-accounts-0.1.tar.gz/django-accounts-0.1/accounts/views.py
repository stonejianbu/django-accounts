from django.shortcuts import render, redirect
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import logout, login, authenticate
from django.contrib.auth.hashers import make_password
from django.contrib.auth.decorators import login_required
from django.core.cache import cache
from django.core.mail import send_mail
from django.http import JsonResponse, HttpResponse
from django.urls import reverse

from django.conf import settings
from django.contrib.auth.models import User

import re
import random


# 类装饰器，类视图应将其作为第一个父类继承
class LoginRequiredMixin:
    '''重写as_view方法为其添加装饰器, 子类继承'''
    @classmethod
    def as_view(cls, **initkwargs):
        view = super(LoginRequiredMixin, cls).as_view(**initkwargs)
        return login_required(view)


# 个人中心页面
class AccountIndex(LoginRequiredMixin, View):
    def get(self, request):
        return render(request, 'index.html')


# 对用户提交信息进行基本的验证（进行正则匹配）
def test_message(username='Null', password='Null', email='Null'):
    # 用户名验证
    username_pattern = r'^[a-zA-Z0-9_-]{5,20}$'
    if (username != 'Null') and not re.match(username_pattern, username):
        return {'username_msg': '提示： 账号有误，请重新输入！'}

    # 密码验证
    password_pattern = r'^[a-zA-Z0-9_]{6,16}$'
    if (password != 'Null') and not re.match(password_pattern, password):
        return {'password_msg': '提示： 密码有误，请重新输入！'}

    # 邮箱验证
    email_pattern = r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$'
    if (email != 'Null') and not re.match(email_pattern, email):
        return {'email_msg': '提示： 邮箱有误，请重新输入！'}
    return None     # 如果验证成功则无返回值


# 对邮箱激活码进行验证
def verify_active_code(active_code, identify):
    # 检查是否存在该key，存在该key时验证是否对应上了，错误则统一返回`激活码错误或者已过期，请重新输入！`
    if not cache.get(identify) or (cache.get(identify) and (active_code != str(cache.get(identify)['active_code']))):
        return {'active_msg': '提示： 激活码错误或者已过期，请重新输入！'}
    return None


# 注册新用户
class RegisterView(View):
    def get(self, request):
        return render(request, 'register.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        active_code = request.POST.get('active_code')
        protocol = request.POST.get('protocol')

        # 对提交信息进行基本验证（根据返回值来响应）
        return_value = test_message(username, password, email)
        if return_value:
            return render(request, 'register.html', return_value)

        # 验证码比对
        active_code_status = verify_active_code(active_code, username)
        if active_code_status:
            return render(request, 'register.html', active_code_status)

        # 其他(判断是否同意网站协议)
        if protocol != 'on':
            protocol_status = {'protocol_msg': '提示： 请阅读并同意网站注册协议！'}
            return render(request, 'register.html', protocol_status)

        # 验证通过，创建用户
        User.objects.create_user(username, email, password)

        # 注册成功，默认设置自动登录
        user = User.objects.get(username=username)
        login(request, user)
        return redirect('accounts:profile')


# 发送邮箱激活码以注册用户
def register_send_email(request):
    # 如果用户使用get该地址则重定向到register页面
    if request.method == 'GET':
        if not request.user.username:
            return redirect('accounts:register')
        return redirect('accounts:profile')
    username = request.POST.get('username')
    password = request.POST.get('password')
    email = request.POST.get('email')

    # 对用户提交的信息进行验证
    return_value = test_message(username, password, email)
    if return_value:
        # 将返回错误信息字典的键都修改为msg，以方便js调用！
        return JsonResponse({'msg': '提示：未输入信息或输入信息有误，请重新输入！'})

    # 随机生成激活码并缓存，将username和激活码绑定保存以后续验证，并设置超时时间5*60s和限制请求次数
    active_code = random.randrange(100000, 999999)
    if cache.get(username):
        time = cache.get(username)['time'] + 1
        if time > 5:
            return JsonResponse({'msg': '提示： 请求过于频繁，请稍后重试！'})
        cache.set(username, {'active_code': active_code, 'time': time})
    else:
        cache.set(username, {'active_code': active_code, 'time': 1}, timeout=5 * 60)

    # 发送激活码
    send_mail(
        subject='用户注册激活码',
        message='您好，欢迎注册本网站，您的注册激活码为%s。' % active_code,
        from_email=settings.EMAIL_FROM,
        recipient_list=[email, ],
    )
    # 返回响应
    return JsonResponse({'msg': '提示： 激活码已发送到您的邮箱，请注意查收！', 'status': 'OK'})


# 用户登录
class LoginView(View):
    def get(self, request):
        if 'username' in request.COOKIES:
            username = request.COOKIES.get('username')
            checked = 'checked'
        else:
            username = ''
            checked = ''
        return render(request, 'login.html', {'username': username, 'checked': checked})

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        vcode = request.POST.get('vcode')

        # 验证码检验
        if vcode.lower() != (request.session['verifycode']).lower():
            error_msg = '提示： 验证码错误，请重新输入！'
            return render(request, 'login.html', {'vcode_msg': error_msg})

        # 用户名和密码的正确性检验
        user = authenticate(request, username=username, password=password)
        if user:
            if user.is_active:
                # 确认登录,并页面跳转
                login(request, user)
                next_url = request.GET.get('next', reverse('accounts:profile'))
                response = redirect(next_url)

                # 判断是否记住用户名，使用cookie记住用户名，限期7天
                if request.POST.get('remember') == 'on':
                    response.set_cookie('username', username, max_age=7 * 24 * 3600)
                else:
                    response.delete_cookie('username')
                return response
            else:
                error_msg = '提示： 账号未激活，请重新输入！'
                return render(request, 'login.html', {'username_msg': error_msg})
        else:
            error_msg = '提示： 请输入正确的账号和密码！'
            return render(request, 'login.html', {'username_msg': error_msg})


# 用户密码修改
class ChangePasswordView(LoginRequiredMixin, View):
    def get(self, request):
        return render(request, 'change_password.html')

    def post(self, request):
        raw_origin_password = request.POST.get('origin_password')
        raw_new_password = request.POST.get('new_password')
        auto_login = request.POST.get('auto_login')

        # 对于用户提交的信息进行基本检验
        return_value = test_message(password=raw_new_password)
        if return_value:
            return render(request, 'change_password.html', return_value)

        # 原始密码比对
        user = request.user
        if not authenticate(request, username=user.username, password=raw_origin_password):
            context = {
                'error_msg': '提示： 原始密码输入信息有误，请重新输入！'
            }
            return render(request, 'change_password.html', context)

        # 通过验证后，设置新密码
        password = make_password(raw_new_password)
        User.objects.filter(username=user.username).update(password=password)

        # 检查是否选择自动登录
        if auto_login == 'on':
            user_obj = User.objects.get(username=user.username)
            login(request, user_obj)

        # 成功后跳转到个人中心
        return redirect('accounts:profile')


# 用户密码重置
class ResetPasswordView(View):
    def get(self, request):
        return render(request, 'reset_password.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        active_code = request.POST.get('active_code')
        auto_login = request.POST.get('auto_login')

        # 根据用户提交的信息进行基本的验证
        return_value = test_message(username=username, password=password)
        if return_value:
            return render(request, 'reset_password.html', return_value)

        # 检验用户是否存在
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            user = None
        if not user:
            return render(request, 'reset_password.html', {'username_msg': '提示： 该用户不存在，请重新输入！'})

        # 验证码比对
        active_code_status = verify_active_code(active_code, username)
        if active_code_status:
            return render(request, 'reset_password.html', active_code_status)

        # 验证通过则重置密码
        password = make_password(password)
        User.objects.filter(username=username).update(password=password)

        # 检查是否选择自动登录
        if auto_login == 'on':
            user = User.objects.get(username=username)
            login(request, user)

        # 重置成功跳转个人中心
        return redirect('accounts:profile')


# 发送邮箱验证码以重置用户密码
def reset_send_email(request):
    if request.method == 'GET':
        if not request.user.username:
            return redirect('accounts:login')
        return redirect('accounts:profile')
    username = request.POST.get('username')
    password = request.POST.get('password')

    # 对用户提交信息进行基本检验
    return_value = test_message(password=password)
    if return_value:
        return JsonResponse({'msg': '提示：未输入信息或输入信息有误，请重新输入！'})

    # 检验账户是否存在
    try:
        user = User.objects.get(username=username)
    except User.DoesNotExist:
        user = None
    if not user:
        return JsonResponse({'msg': '提示：未输入信息或输入信息有误，请重新输入！'})

    # 随机生成激活码并缓存，将username和激活码绑定保存以后续验证，并设置超时时间5*60s和限制请求次数
    active_code = random.randrange(100000, 999999)
    if cache.get(username):
        time = cache.get(username)['time'] + 1
        if time > 5:
            return JsonResponse({'msg': '提示： 请求过于频繁，请稍后重试！'})
        cache.set(username, {'active_code': active_code, 'time': time})
    else:
        cache.set(username, {'active_code': active_code, 'time': 1}, timeout=5 * 60)

    # 获取当前申请重置账户的邮箱地址并发送邮箱激活码
    email = user.email
    send_mail(
        subject='密码重置',
        message='您好，%s欢迎注册本网站，密码重置激活码为%s。' % (username, active_code),
        from_email=settings.EMAIL_FROM,
        recipient_list=[email, ],
    )
    # 返回响应
    return JsonResponse({'msg': '提示： 验证码已发送到您的邮箱，请注意查收！', 'status': 'OK'})


# 用户退出登录状态
class LogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('accounts:login')


# 图片验证码
@csrf_exempt
def verifycode(request):
    # 引入绘图模块
    from PIL import Image, ImageDraw, ImageFont
    # 引入随机函数模块
    import random
    from django.utils.six import BytesIO
    # 定义变量，用于画面的背景色、宽、高
    bgcolor = (random.randrange(140, 200), random.randrange(
        120, 200), random.randrange(100, 220))
    width = 100
    height = 30
    # 创建画面对象
    im = Image.new('RGB', (width, height), bgcolor)
    # 创建画笔对象
    draw = ImageDraw.Draw(im)
    # 调用画笔的point()函数绘制噪点
    for i in range(0, 150):
        xy = (random.randrange(0, width), random.randrange(0, height))
        fill = (random.randrange(0, 255), 255, random.randrange(0, 255))
        draw.point(xy, fill=fill)
    # 定义验证码的备选值,去掉易混淆的0 o 1 i 2 z，且在后面程序中设置大小写不敏感
    str1 = 'abcdefghjkmnpqrstuvwxyABCD3EFGHJK456LMNPQRS789TUVWXY'
    # 随机选取4个值作为验证码
    rand_str = ''
    for i in range(0, 4):
        rand_str += str1[random.randrange(0, len(str1))]
    # 构造字体对象
    font = ImageFont.truetype('FreeMono.ttf', 23)
    # 构造字体颜色
    fontcolor = (255, random.randrange(0, 255), random.randrange(0, 255))
    # 绘制4个字
    draw.text((5, 2), rand_str[0], font=font, fill=fontcolor)
    draw.text((25, 2), rand_str[1], font=font, fill=fontcolor)
    draw.text((50, 2), rand_str[2], font=font, fill=fontcolor)
    draw.text((75, 2), rand_str[3], font=font, fill=fontcolor)
    # 释放画笔
    del draw
    # 存入session，用于做进一步验证
    request.session['verifycode'] = rand_str
    # 内存文件操作
    buf = BytesIO()
    # 将图片保存在内存中，文件类型为png
    im.save(buf, 'png')

    # 因为大小写问题post而导致这个程序无法运行
    if request.method == 'POST':
        img = "<img src='%s' alt='验证码'>" % buf.getvalue()
        return JsonResponse({'img': img})
    # 将内存中的图片数据返回给客户端，MIME类型为图片png
    return HttpResponse(buf.getvalue(), 'image/png')


def protocol_content(request):
    return render(request, 'protocol_content.html')
